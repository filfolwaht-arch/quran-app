-- ============================================================================
-- Migration 005: Username availability check (RPC)
-- ----------------------------------------------------------------------------
-- The RLS policies in migration 002 deliberately only let a user see their
-- OWN profile row -- which means a plain `select ... where username = $1`
-- from the browser can never be used to check availability (it would always
-- come back empty, RLS-blocked, even for taken usernames).
--
-- This function is the narrow, safe exception: it runs as SECURITY DEFINER
-- so it can see every row, but it only ever returns a single boolean and
-- nothing else about any profile. It's callable by anon so it works on the
-- sign-up page before a session exists, and by authenticated so it also
-- works from the settings page.
-- ============================================================================

create or replace function public.is_username_available(check_username text)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select not exists (
    select 1 from public.profiles where username = check_username
  );
$$;

comment on function public.is_username_available is
  'Returns true if no profile currently has this username. Leaks no other data.';

grant execute on function public.is_username_available(text) to anon, authenticated;
