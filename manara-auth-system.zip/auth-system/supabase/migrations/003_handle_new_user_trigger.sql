-- ============================================================================
-- Migration 003: Auto-create a profile row on signup
-- ----------------------------------------------------------------------------
-- Fires after every insert into auth.users (i.e. every successful signUp())
-- and creates the matching public.profiles row. Runs as SECURITY DEFINER so
-- it can write to public.profiles regardless of the caller's own grants, and
-- pins search_path explicitly, which is the standard hardening against
-- search_path hijacking for definer functions.
--
-- full_name / username / preferred_language are read from the metadata
-- passed by the client as the `options.data` argument of supabase.auth.
-- signUp() (see js/signup.js). If any of them is missing the insert still
-- succeeds -- profiles.full_name/username are nullable specifically so a
-- signup can never be blocked by this trigger.
-- ============================================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, username, preferred_language)
  values (
    new.id,
    new.raw_user_meta_data ->> 'full_name',
    new.raw_user_meta_data ->> 'username',
    coalesce(new.raw_user_meta_data ->> 'preferred_language', 'en')
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
