-- ============================================================================
-- Migration 002: Row Level Security for profiles
-- ----------------------------------------------------------------------------
-- Two separate layers of access control are required for the table to be
-- reachable AND locked down correctly:
--
--   1) RLS POLICIES  -- row-level rules evaluated per-request (who can see /
--      change WHICH rows).
--   2) ROLE GRANTS    -- table/column-level permissions that decide whether
--      the anon/authenticated Postgres roles can reach the table through the
--      Data API (PostgREST) at all. Supabase now exposes tables through the
--      Data API only when a role has an explicit grant -- RLS alone is no
--      longer sufficient on current projects, so both are set up here.
--
-- No DELETE policy or grant is defined anywhere below. Account deletion is
-- out of scope for this system (it requires the service role / an Edge
-- Function), so by omission a user can never delete their own or anyone
-- else's profile row through the client.
-- ============================================================================

alter table public.profiles enable row level security;

-- --- Row-level policies -----------------------------------------------------

create policy "Users can view their own profile"
  on public.profiles
  for select
  to authenticated
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles
  for update
  to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Defensive/self-healing: lets a signed-in user (re)create their own row if
-- it's ever missing. Normal signup never hits this path -- the trigger in
-- migration 003 creates the row server-side with elevated privileges.
create policy "Users can insert their own profile"
  on public.profiles
  for insert
  to authenticated
  with check (auth.uid() = id);

-- --- Data API role grants ----------------------------------------------------
-- Least privilege: authenticated users can read/write; anon gets nothing on
-- this table (there is nothing an unauthenticated visitor should see here).

grant select, insert, update on public.profiles to authenticated;
