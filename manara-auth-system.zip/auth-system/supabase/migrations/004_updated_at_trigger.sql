-- ============================================================================
-- Migration 004: Keep updated_at current automatically
-- ----------------------------------------------------------------------------
-- Generic trigger function, reusable on any table that has an updated_at
-- column. Stamps the row with now() on every UPDATE so the client never has
-- to (and can't forget to, or fake it).
-- ============================================================================

create or replace function public.handle_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_profiles_updated_at on public.profiles;

create trigger set_profiles_updated_at
  before update on public.profiles
  for each row execute function public.handle_updated_at();
