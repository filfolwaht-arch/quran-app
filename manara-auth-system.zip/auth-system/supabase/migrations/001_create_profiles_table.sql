-- ============================================================================
-- Migration 001: Create profiles table
-- ----------------------------------------------------------------------------
-- One row per authenticated user, linked 1:1 to auth.users via a shared UUID
-- primary key. auth.users itself is managed entirely by Supabase Auth and
-- should never be modified directly -- this table is where OUR application
-- data about a user lives.
-- ============================================================================

create table if not exists public.profiles (
  -- Same UUID as auth.users.id. Deleting the auth user cascades here.
  id uuid primary key references auth.users (id) on delete cascade,

  full_name text,
  username text unique,
  avatar_url text,

  -- UI language the user last chose. Kept in sync with localStorage by the
  -- front end; used to pre-select the right language on a new device.
  preferred_language text not null default 'en',

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint preferred_language_valid check (preferred_language in ('en', 'fr', 'ar')),

  -- Nullable at the DB level on purpose: the sign-up trigger (migration 003)
  -- must never fail because one optional field was missing. The 3-20 char
  -- alphanumeric/underscore rule is the one thing worth enforcing here since
  -- it also protects the uniqueness constraint from junk values.
  constraint username_format check (username is null or username ~ '^[a-zA-Z0-9_]{3,20}$')
);

comment on table public.profiles is
  'Public-facing profile data for each user. 1:1 with auth.users.';
comment on column public.profiles.id is
  'Matches auth.users.id. Do not generate a separate id.';
comment on column public.profiles.preferred_language is
  'One of en / fr / ar. Drives i18n on first load from a new device.';

-- Fast lookups for the "is this username taken" check (signup + settings).
create index if not exists profiles_username_idx on public.profiles (username);
